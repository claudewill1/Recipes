from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
import re

class Recipe:
    db = "recipes_schema"
    def __init__(self,data) -> None:
        self.id = data["id"]
        self.name = data["name"]
        self.under30minutesYesOrNo = data["under30minutesYesOrNo"]
        self.description = data["description"]
        self.instructions = data["instructions"]
        self.date_made_on = data["date_made_on"]
        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]

    @classmethod
    def getAllByUserId(cls,data):
        query = "SELECT * FROM recipes AS r LEFT JOIN users AS u ON recipes.user_id = users.id WHERE u.id = %(id)s;"
        results = connectToMySQL(cls.db).query_db(query,data)
        recipes = []
        if not results:
            recipes = []
        else:
            for row in results:
                recipes.append(cls(row))
        return recipes

    @classmethod
    def getOneRecipeByUserId(cls,id):
        query = "SELECT * FROM recipes AS r LEFT JOIN users AS u ON r.user_id = u.id WHERE u.id = %(id)s ORDER BY r.id LIMIT 1);"
        data = {
            "id": id
        }
        results = connectToMySQL(cls.db).query_db(query,data)
        if len(results) < 1:
            return False
        return cls(results[0])

    @classmethod
    def updateRecipe(cls,data):
        query = "UPDATE TABLE recipes SET name = %(name)s,under30minutesYesOrNo = %(under30minutesYesOrNo)s,description = %(description)s,instructions = %(instructions)s;"
        return connectToMySQL(cls.db).query_db(query,data)

    @classmethod 
    def deleteRecipe(cls,id):
        query = "DELETE FROM recipes WHERE id = %(id)s;" 
        data = {
            "id": id
        }
        return connectToMySQL(cls.db).query_db(query,data)

    @staticmethod
    def validateRecipe(recipe):
        isValid = True
        if len(recipe["name"]) < 2:
            flash("Recipe name cannot be blank and must have at least 3 characters.")
            isValid = False
        if len(recipe["description"]) < 38:
            flash("Description cannot be blank and must have at least 3 characters.")
            isValid = False
        if len(recipe["instructions"]) < 3:
            flash("Instructions cannot be blank and must have at least 3 characters.")
